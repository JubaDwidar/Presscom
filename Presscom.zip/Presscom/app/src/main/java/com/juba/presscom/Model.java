package com.juba.presscom;

public class Model {
    private String username,desc,pic;

    public Model(String username, String desc, String pic) {
        this.username = username;
        this.desc = desc;
        this.pic = pic;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}
