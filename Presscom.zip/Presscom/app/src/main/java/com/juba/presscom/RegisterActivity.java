package com.juba.presscom;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    private FirebaseAuth mauth;
    private EditText registerUsername, registerPassword;
    private Button registerBtn, signingBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initialize();
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createNewAccount();
            }
        });

        signingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendUserForLogin();
            }
        });

    }

    private void createNewAccount() {
        String regiterName = registerUsername.getText().toString();
        String regiterPassword = registerUsername.getText().toString();
        mauth.createUserWithEmailAndPassword(regiterName, regiterPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                sendUserToMain();
            }
        });
    }

    private void initialize() {
        mauth = FirebaseAuth.getInstance();
        registerBtn = findViewById(R.id.signup_btn);
        registerUsername = findViewById(R.id.register_name);
        registerPassword = findViewById(R.id.register_password);
        signingBtn = findViewById(R.id.signing_button);

    }

    private void sendUserForLogin()

    {
        Intent loginIntent = new Intent(this, LoginActivity.class);
        startActivity(loginIntent);

    }

    private void sendUserToMain() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        startActivity(mainIntent);
    }
}
