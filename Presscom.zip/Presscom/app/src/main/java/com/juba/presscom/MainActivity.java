package com.juba.presscom;

import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.google.firebase.auth.FirebaseAuth;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.zip.Inflater;

import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mauth;
    private String currentuser;
    private Toolbar mainToolBar;
    private HomeFragment homeFragment;
    private PersonalFragment personalFragment;
    private NotificationFragment notificationFragment;
    private AHBottomNavigation bottomNavigation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainToolBar = findViewById(R.id.post_layout);
        setSupportActionBar(mainToolBar);
        getSupportActionBar().setTitle("PressCom");
        bottomNavigation = findViewById(R.id.navigation_btm);

        homeFragment = new HomeFragment();
        personalFragment = new PersonalFragment();
        notificationFragment = new NotificationFragment();

        mauth = FirebaseAuth.getInstance();
        currentuser = mauth.getCurrentUser().getUid();

        bottomNavigation.setOnNavigationPositionListener(new AHBottomNavigation.OnNavigationPositionListener() {
            @Override
            public void onPositionChange(int y) {
                switch (y) {
                    case R.id.home_nav:
                        FragmentTransaction(homeFragment);

                    case R.id.personal_nav:
                        FragmentTransaction(personalFragment);

                    case R.id.noti_nav:
                        FragmentTransaction(notificationFragment);

                }


            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (currentuser == null) {
            sendToLogin();

        } else

        {

            sendToSetup();
        }


    }

    private void sendToLogin() {
        Intent loginIntent = new Intent(this, LoginActivity.class);
        startActivity(loginIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.logout_setup:
                logOut();
                sendToLogin();
                return true;
            case R.id.acount_setup:
                sendToSetup();
                return true;
        }
        return false;
    }

    private void sendToSetup() {
        Intent setupIntent = new Intent(this, SetupActivity.class);
        startActivity(setupIntent);
    }

    private void logOut() {
        mauth.signOut();
    }


    public void FragmentTransaction(android.support.v4.app.Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.main_container, fragment);
        transaction.commit();


    }

}
