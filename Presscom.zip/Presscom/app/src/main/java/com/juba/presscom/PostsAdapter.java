package com.juba.presscom;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class PostsAdapter extends RecyclerView.Adapter<PostsAdapter.PostsHolder> {

    private List<Model> modelList;


    public PostsAdapter(List<Model> list) {
        modelList = list;
    }

    @NonNull
    @Override
    public PostsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item, viewGroup, false);

        return new PostsHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull PostsHolder postsHolder, int i) {
        String desc = modelList.get(i).getDesc();
        String name = modelList.get(i).getUsername();
        postsHolder.username.setText(name);
        postsHolder.desc.setText(desc);
        Picasso.get().load(modelList.get(i).getPic()).into(postsHolder.postspic);


    }


    @Override
    public int getItemCount() {
        return modelList.size();
    }

    public class PostsHolder extends RecyclerView.ViewHolder {

        private CircleImageView userImage;
        private TextView username, desc;
        private ImageView postspic;

        public PostsHolder(@NonNull View itemView) {
            super(itemView);
            userImage = itemView.findViewById(R.id.user_image);
            username = itemView.findViewById(R.id.username);
            desc = itemView.findViewById(R.id.post_desc);
            postspic = itemView.findViewById(R.id.post_pic);

        }
    }
}
